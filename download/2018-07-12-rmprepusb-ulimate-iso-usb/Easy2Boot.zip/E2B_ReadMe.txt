To make a MultiBoot USB drive, right-click on \MAKE_E2B_USB_DRIVE (run as admin).cmd and run as Administrator
or read \_ISO\docs\Make_E2B_USB_Drive\ReadMe.txt

See www.easy2boot.com for more information.

