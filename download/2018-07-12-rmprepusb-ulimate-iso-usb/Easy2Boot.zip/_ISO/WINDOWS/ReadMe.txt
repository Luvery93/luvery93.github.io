If you have Windows XP, Vista, Win7, Win8, SVR2K8R2, SVR2012, Win10 install .ISO files then copy them to the appropriate folder.

DO NOT COPY .ISO files to the \_ISO\WINDOWS folder - they will not be found by E2B!

You must copy Windows Installer ISOs to the correct sub-folder (3rd level)...

\_ISO\WINDOWS\XP                          - Windows XP Installer .ISO files (.imgPTN* files are NOT supported)
\_ISO\WINDOWS\VISTA, WIN7, SVR2K8R2, etc. - Windows Installer .ISO and .imgPTN* files are supported

.imgPTN files are not supported in the \_ISO\WINDOWS\XP folder - only add Windows XP Install .ISO files to this folder.

See the www.easy2boot.com website for more details on Easy2Boot.

You can also add you own unattend.xml files and Product Key files.

See http://www.easy2boot.com/add-payload-files/xmltoe2b-exe-utility/