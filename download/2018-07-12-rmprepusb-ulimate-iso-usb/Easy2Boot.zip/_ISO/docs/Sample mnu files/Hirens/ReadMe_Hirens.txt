The best way to have multiple Hirens versions on one E2B drive
is to convert each Hirens ISO to a FAT32 Image Partition File (.imgPTN)
uaing MakePartImage.
The E2B USB drive itself does not have to be FAT32 (it can be NTFS or FAT32).
