Here are instructions for adding POS2009.iso to Easy2Boot

1. Extract \i386 folder to root of Easy2Boot USB drive
2. Extract all \win*.* files to the root of the Easy2Boot USB drive
3. Copy POS2009.iso to the \_ISO\MainMenu folder and rename as POS2009.isowinv

To use:
1. Select POS2009.isowinv from Easy2Boot main menu
2. Allow to boot to POS setup and enter product key and continue install
3. When it reboots -allow to boot from the internal hard disk (keep Easy2Boot USB drive connected)
