This folder contains different Themes for E2B

To be able to change Themes using a Main Menu entry:

1. Copy the $Change_Theme.mnu file to the \_ISO\MAINMENU
2. Copy the $Default E2B Menu.cfg file to \_ISO folder and rename it to MyE2B.cfg


You can instead copy the .cfg files to a menu folder (e.g. \_ISO\MAINMENU)
