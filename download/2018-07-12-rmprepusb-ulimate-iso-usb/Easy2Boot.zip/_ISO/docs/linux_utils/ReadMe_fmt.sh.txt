

fmt.sh
======

This is a linux bash shell script which will install Easy2Boot onto a USB drive.
It will format an existing partition on the USB drive as FAT32 - it does not partition the USB drive.
If your USB drive is unformatted or has no partition table, 
you will need to make a new Active FAT32 Primary partition first using fdisk.

Note: if you get the error
./fmt.sh: 10: ./fmt.sh: [[: not found
then it is not running bash - try the command
sudo bash ./fmt.sh


INSTRUCTIONS
============

WARNING: THIS SCRIPT IS DANGEROUS - IF YOU INPUT THE WRONG DEVICE NAME YOU COULD DESTROY A DIFFERENT PARTITION!

USE THIS SCRIPT AT YOUR OWN RISK!

1. Extract the Easy2Boot .ZIP file to your Documents folder on your linux system (must be on an ext2/3/4 volume)

2. Click on target USB drive icon - this mounts it and makes it easier to find

3. Find the \_ISO\docs\linux_utils folder

4. Right-click inside the \_ISO\docs\linux_utils folder and select Open In Terminal (or press CTRL+ALT+T)

5. This should open up a bash command shell at the linux_utils folder.

6. Now type these two commands

sudo chmod 777 *
sudo ./fmt.sh                 (or try     sudo bash ./fmt.sh   if you get errors)


make sure you input the correct device and partition name when prompted - e.g. /dev/sdc1  or /dev/sdd1 or /dev/sde1, etc. !!!!
