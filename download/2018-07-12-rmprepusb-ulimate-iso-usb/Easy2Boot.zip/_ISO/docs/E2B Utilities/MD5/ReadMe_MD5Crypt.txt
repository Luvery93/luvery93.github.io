MD5Crypt
========

Unzip MD5Crypt.zip first to the same folder.

1. Double-click to run MD5crypt.exe file to run it

2. Enter the password that you want encrypted - e.g. fred

3. Use the Windows console 'Edit - Mark' feature (click top-left of console window) to highlight the encrypted password and press ENTER

4. Paste the encrypted password into your \_ISO\MyE2B.cfg file

See MD5_Example.GIF