To use your own language

1. Copy the \_ISO\e2b\grub\ENG folder to a new folder - e.g. \_ISO\e2b\grub\FRED
2. Edit the STRINGS.txt and F1.cfg file in the new folder
3. In \_ISO\MyE2B.cfg (copy of \_ISO\Sample_MyE2B.cfg)  set LANG=FRED and change heading, HELPTEXT footer, etc. as required
4. If you want to change the text messages in \_ISO\e2b\grub\Menu.lst  then copy it to \_ISO\e2b\grub\FRED\Menu.lst (not recommended)

Note: If /_ISO/STRINGS.txt exists, it will always be used (LANG is ignored)
	     
See www.easy2boot.com for more information
