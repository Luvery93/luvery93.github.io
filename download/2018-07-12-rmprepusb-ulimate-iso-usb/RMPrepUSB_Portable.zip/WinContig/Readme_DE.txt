***********************************************************
WinContig 1.35.04
Copyright � 2006-2015 Marco D'Amato
Web: http://wincontig.mdtzone.it/en/index.htm
E-mail: md@mdtzone.it
***********************************************************
 
WinContig ist ein einfach zu bedienendes, eigenst�ndiges Defragmentierungwerkzeug, das keine Installationsverzeichnisse oder Registry-Eintr�ge auf dem Computer erstellt. Damit k�nnen einzelne Dateien schnell defragmentiert werden, ohne den gesamten Datentr�ger defragmentieren zu m�ssen. Dar�ber hinaus erm�glicht WinContig, Dateien in Profile zu gruppieren und akzeptiert eine Reihe von optionalen Befehlszeilenoptionen f�r die Programmsteuerung.

WinContig l�uft auf Windows XP, Windows Vista, Windows 7 und Windows 8/8.1 Betriebssysteme.

Benutzer von Windows XP, Windows Vista, Windows 7 oder Windows 8/8.1 m�ssen �ber volle Administratorrechte verf�gen.


==================================================================== 
Lizenz
====================================================================
WinContig ist als Freeware f�r den pers�nlichen und kommerziellen Gebrauch freigegeben.


====================================================================
Endnutzer-Lizenzvereinbarung
====================================================================
Diese Software und alle zugeh�rigen Dateien werden vom Autor "wie besehen" angeboten ohne jegliche ausdr�ckliche oder stillschweigende Garantien, einschlie�lich, aber nicht beschr�nkt, auf die gesetzlichen Garantien der Marktg�ngigkeit und der Eignung f�r einen bestimmten Zweck. In keinem Fall haftet der Autor f�r Sch�den jeglicher Art (einschlie�lich und ohne Einschr�nkung f�r Sch�den aus entgangenem Gewinn, Nutzungsausfall von Daten, Betriebsunterbrechung, Verlust gesch�ftlicher Informationen oder irgendeinem anderen Verm�gensschaden), die aus der Nutzung oder Verwendungsunf�higkeit dieses Produktes hervorgehen m�gen, selbst wenn auf die M�glichkeit solcher Sch�den hingewisen wurde. Das gesamte Risiko aus der Nutzung oder Leistung dieses Produktes und der Dokumentation liegt beim Anwender.

Die Informationen in diesem Dokument k�nnen ohne Vorank�ndigung ge�ndert werden und stellen keine Verpflichtung seitens des Autors. Die Software f�r das in diesem Dokument beschriebene Produkt wird unter dieser Lizenzvereinbarung zur Verf�gung gestellt.

Die Verwendung dieses Produktes f�r einen beliebigen Zeitraum stellt Ihr Einverst�ndnis mit dieser Vereinbarung und unterwirft Sie seinem Inhalt.


====================================================================
Installation
====================================================================
WinContig ist eine eigenst�ndige ausf�hrbare Datei, die keine Installation oder zus�tzliche DLLs erfordert. Um sie zu nutzen, extrahieren Sie den Inhalt des ZIP-Archivs in einen beliebigen Ordner und doppelklicken Sie die ausf�hrbare Datei.

HINWEIS: Vor der Installation der aktuellen Version von WinContig muss die alte Version entfernt werden. Bei der ersten Ausf�hrung werden alle Einstellungen auf die Standardwerte zur�ckgesetzt.


==================================================================== 
R�ckmeldungen
====================================================================
Wenn Sie Anregungen oder Kommentare haben oder einen Fehler in WinContig finden, senden Sie bitte eine Nachricht an md@mdtzone.it zur�ck.


====================================================================
Urheber-und Markenzeichenrecht
====================================================================
Windows, Windows XP, Windows Vista, Windows 7, Windows 8 und Windows 8.1 sind Markenzeichen der Microsoft Corporation. Alle anderen Markenzeichen sind Eigentum ihrer jeweiligen Inhaber.